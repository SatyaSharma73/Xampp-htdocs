<?php

$con=mysqli_connect("localhost","root","","medicine_order");
?>