
<a class="logout" href="login_do.php?logout=true"><button type="button" name="button" class="w-10 btn btn-lg btn-warning">Logout</button></a>

 <style>
 	.logout{
  text-decoration: none;
  color: #ff006e;
   font-weight: bolder;
  font-family: sans-serif;
  position: absolute;
  right: 50px;
  top: 20px;
}
 </style>