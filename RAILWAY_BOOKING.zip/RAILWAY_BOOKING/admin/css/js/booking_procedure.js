window.alert("sometext");
