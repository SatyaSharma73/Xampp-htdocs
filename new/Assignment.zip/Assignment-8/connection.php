<?php

$con=mysqli_connect("localhost","root","","software_food");
?>