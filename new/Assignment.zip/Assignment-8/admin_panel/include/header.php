
<a class="logout" href="login_do.php?logout=true">Logout</a>

 <style>
 	.logout{
  text-decoration: none;
  color: #ff006e;
   font-weight: bolder;
  font-family: sans-serif;
}
 </style>