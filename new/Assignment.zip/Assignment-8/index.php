<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link href="signin.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@700&display=swap" rel="stylesheet">
  </head>
  <style>
html,
body {
  height: 100%;
}
a{
  text-decoration: none;
  color: Pink;
}

h1{
  color: Black;
  font-family: 'Libre Baskerville', serif;
}
body {
  display: flex;
  align-items: center;
  padding-top: 20px;
  padding-bottom: 20px;
  overflow: hidden;
  background-color: #80ffdb;
}
main{
  padding-top: 10px;
}
.form-signin {
  width: 100%;
  max-width: 530px;
  padding: 1px;

  margin-left: auto;
    margin-right: auto;
    margin-top: 100px;
}
</style>

 <body class="text-center">
 	<main class="form-signin">
    
     <h1 class="fs-1">This is from Frontend</h1>
    <p class="fs-3">Developed by Smriti Choudhury_CS 3B_60</p>

    <p class="text">Software Engineering Lab Assignment-8  &copy; Smriti Choudhury_CS 3B_60 </p>
    

  <a href="employee.php"><button type="button" name="button" class="w-10 btn btn-lg btn-success">Food</button></a>
    <a href="dept.php"><button type="button" name="button" class="w-10 btn btn-lg btn-primary">Category</button></a>


</main>


  





</body>  
</html>
