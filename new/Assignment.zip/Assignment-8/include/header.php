<a href="login_do.php?logout=true">Logout</a>
