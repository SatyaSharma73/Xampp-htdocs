<a href="customer_login_do.php?logout=true"><button type="button" class="btn btn-dark"><i class="fa fa-sign-out" aria-hidden="true">Logout</i></button></a>
